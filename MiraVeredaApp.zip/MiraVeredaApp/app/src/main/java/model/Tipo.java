package model;

public enum Tipo {
    SERIE,
    PELICULA,
    CAPITULO;
}
