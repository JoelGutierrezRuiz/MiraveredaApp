package model;

public class Serie {
}
