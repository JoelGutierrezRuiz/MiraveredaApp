/*public class Pelicula extends model.Contenido{

}*/
