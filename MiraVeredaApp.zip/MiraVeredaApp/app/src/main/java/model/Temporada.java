package model;

public class Temporada{
}
