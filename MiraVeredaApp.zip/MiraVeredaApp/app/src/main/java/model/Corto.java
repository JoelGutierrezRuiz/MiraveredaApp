/*public class Corto extends model.Contenido{
}
*/